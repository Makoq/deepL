pip install xx --break-system-packages
pip install -r requirement.txt --break-system-packages
python gan.py
